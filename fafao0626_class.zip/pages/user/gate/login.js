$(document).ready(function () {
  // 푸터 언어 선택기능
  $(".policy-list .language-checked > a").click(function () {
    // 초기화
    var box = $(this)
      .parents()
      .find(".policy")
      .children()
      .eq(1)
      .addClass("policy-language--up");

    box.find("ul").css("display", "block");
    $(this).css("visibility", "hidden");

    $(".policy-language ul>li").mouseenter(function () {
      $(".policy-language ul>li").removeClass("language-selected");
      $(this).css("background", "#eeeeee");
      $(this).siblings().css("background", "#ffffff");
    });

    $(".policy-language ul").mouseleave(function () {
      box.find("ul").css("display", "none");
      $(this).parent().removeClass("policy-language--up");
      $(".policy-list .language-checked > a").css("visibility", "visible");
    });
  });
});
