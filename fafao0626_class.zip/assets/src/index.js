$(document).reday(function () {
  alert("hi");
});
